# Deployment guide

## 0. Obtain approval first

This prototype uses the IIT Indore name/domain and handles dating-related profiles and private communications. Obtain written institutional approval, define an accountable operator, publish moderator contact details, and have the Terms/Privacy Notice reviewed before inviting students.

Do not use IIT Indore's official logo unless you have permission. The supplied logo is original and the website states that it is unofficial.

## 1. Create the Google OAuth client

1. Open Google Cloud Console and create/select a project.
2. Configure the OAuth consent screen.
3. Create an **OAuth Client ID → Web application**.
4. Add authorized JavaScript origins:
   - Local testing: `http://localhost:5500`
   - GitHub Pages: `https://YOUR_GITHUB_USERNAME.github.io`
   - Your custom HTTPS domain, when applicable
5. Copy the Web Client ID. It ends with `.apps.googleusercontent.com`.

For a project repository such as `https://username.github.io/iiti-spark/`, the authorized **origin** is still `https://username.github.io` without the path.

The browser's `hd` value is only a sign-in hint. The supplied backend also checks the signed token's `hd` claim and the verified email domain.

## 2. Create the Apps Script backend

1. Create a new standalone Google Apps Script project.
2. Add `Config.gs` and `Code.gs` from `backend-apps-script/`.
3. Open **Project Settings → Show `appsscript.json` manifest file**, then replace it with the supplied manifest.
4. Run `setupProject()` once from the Apps Script editor.
5. Approve the requested Sheets, Drive, and external-request permissions.
6. Open the execution log. It contains the new master spreadsheet and data-folder links.
7. Run:

```javascript
configureApp(
  "YOUR_WEB_CLIENT_ID.apps.googleusercontent.com",
  "iiti.ac.in",
  ["http://localhost:5500", "https://YOUR_GITHUB_USERNAME.github.io"]
);
```

Optional custom uploads are disabled by default because the simple Drive implementation requires link-accessible files. Google profile photos work without enabling this. To enable the documented pilot-only upload mode, run:

```javascript
enablePublicPhotoUploads();
```

## 3. Deploy Apps Script as a web app

1. Click **Deploy → New deployment**.
2. Select **Web app**.
3. Execute as: **Me**.
4. Who has access: choose the option that permits your GitHub Pages frontend to call the endpoint. In many accounts this is **Anyone**.
5. Deploy and copy the URL ending in `/exec`.

The endpoint is public at the network level, but application actions require a verified login and hashed bearer session. The GitHub frontend talks to a sandboxed Apps Script bridge iframe; the bridge accepts messages only from the configured `ALLOWED_WEB_ORIGINS`. Do not expose the master spreadsheet or Drive folder.

Test the health response in a browser:

```text
YOUR_EXEC_URL?action=health
```

It should state `"endToEndEncrypted": false`.

## 4. Configure the frontend

Edit `frontend/config.js`:

```javascript
window.IITI_SPARK_CONFIG = {
  API_URL: "YOUR_APPS_SCRIPT_EXEC_URL",
  GOOGLE_CLIENT_ID: "YOUR_WEB_CLIENT_ID.apps.googleusercontent.com",
  ALLOWED_DOMAIN: "iiti.ac.in",
  APP_NAME: "IITI Spark",
  TERMS_VERSION: "2026-07-21",
  DEMO_MODE: false,
  CHAT_POLL_MS: 3000
};
```

The `TERMS_VERSION` must match the Apps Script Script Property. After changing the legal text, update both values and require users to accept the new version.

## 5. Test locally

From the repository root:

```bash
python -m http.server 5500 --directory frontend
```

Open `http://localhost:5500`. Do not open `index.html` directly with a `file://` URL because Google Sign-In requires an authorized web origin.

Test with at least two eligible accounts so you can verify mutual matching and chat.

## 6. Deploy to GitHub Pages

1. Create a GitHub repository and push this folder to the `main` branch.
2. Open **Repository Settings → Pages**.
3. Under **Build and deployment**, choose **GitHub Actions**.
4. The included workflow uploads only `frontend/` and deploys it.
5. Open the Pages URL after the workflow succeeds.

You can alternatively use “Deploy from a branch,” but the included Actions workflow is already configured for this repository layout.

## 7. Restrict backend access

- Share the master spreadsheet and data folder only with named moderators/administrators.
- Never publish the sheet or turn on “anyone with the link” for database workbooks.
- Protect header columns and administrative status fields.
- Create a separate operator account instead of using a personal primary account.
- Review `REPORTS` and establish an emergency escalation process before launch.
- Add a time-driven trigger for `cleanupExpiredSessions()` once per day.

## 8. Updating the backend

After changing Apps Script code:

1. **Deploy → Manage deployments**.
2. Edit the active deployment.
3. Select **New version**.
4. Deploy.

The `/exec` URL normally remains the same when updating the existing deployment.
