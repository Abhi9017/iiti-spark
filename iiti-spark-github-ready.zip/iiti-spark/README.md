# IITI Spark

A GitHub Pages + Google Apps Script + Google Sheets/Drive MVP for an **unofficial, 18+, IIT Indore student social-discovery prototype**.

The interface includes:

- Google Identity Services sign-in with backend enforcement of the verified `hd=iiti.ac.in` claim
- Terms, age confirmation, privacy notice, and an unofficial-service disclaimer
- Profile setup, Google profile photo support, optional Drive photo uploads
- Neon swipe cards with pass/like actions
- Mutual matching only
- Match list and polling-based chat
- Report, block, discovery visibility, sign-out, and account anonymization
- A sandboxed Apps Script bridge for GitHub Pages without putting messages or tokens in URLs
- Google Sheets sharding for swipe/chat rows and automatic creation of extra workbook parts

## Critical security statement

**This project does not provide end-to-end encryption. Do not describe it as end-to-end encrypted.**

Messages are sent over HTTPS to the Apps Script web app and stored in Google Sheets. Backend spreadsheet administrators can access them. The UI states this clearly.

The code does **not** collect or store Google passwords. Google returns an ID token; the backend verifies it and stores only a hash of the app's own session token.

## Repository layout

```text
frontend/                 Static GitHub Pages app
backend-apps-script/      Google Apps Script backend
.github/workflows/        GitHub Pages deployment
DEPLOYMENT.md             Exact setup and deployment steps
SECURITY.md               Security limits and production migration
ADMIN.md                  Moderation and data-handling checklist
```

## Storage design

The master spreadsheet contains indexes and administrative tables:

- `USERS`
- `MATCHES`
- `SESSIONS`
- `LIKES_INDEX`
- `BLOCKS`
- `REPORTS`
- `SHARDS`
- `AUDIT`

High-growth events use rolling tabs:

- `SWIPES_0001`, `SWIPES_0002`, ...
- `CHAT_0001`, `CHAT_0002`, ...

Each event tab rolls over after 40,000 rows by default. Before a workbook reaches the configured 8,000,000-cell safety threshold, the backend creates `IITI Spark — Data Part 002`, then later parts, and records every location in the master `SHARDS` index.

Google Sheets currently supports up to 10 million cells per spreadsheet; the lower project threshold leaves operational headroom.

### Why there is no sheet per person

A separate tab or spreadsheet for every student creates duplicated personal data, permission mistakes, a very large number of files/tabs, and expensive reads. The safer design stores one normalized user row and partitions only high-volume events. The `userId`, `matchId`, and shard index still allow continuous retrieval per person or match.

## Pilot vs production

This repository is suitable for a small, controlled pilot after institutional approval and a privacy/safety review. It is not a production-scale dating platform. Before a real launch, move authentication verification, sessions, chat, media storage, abuse controls, backups, and deletion workflows to a production backend. See [SECURITY.md](SECURITY.md).

## Start here

Follow [DEPLOYMENT.md](DEPLOYMENT.md) exactly.
